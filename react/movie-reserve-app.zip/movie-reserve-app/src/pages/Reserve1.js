import React from 'react';

const Reserve = () => {
  return <h1>영화 예매 페이지</h1>;
};

export default Reserve;