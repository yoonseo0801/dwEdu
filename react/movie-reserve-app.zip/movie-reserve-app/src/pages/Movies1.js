import React from 'react';

const Movies = () => {
  return <h1>영화 목록 페이지</h1>;
};

export default Movies;