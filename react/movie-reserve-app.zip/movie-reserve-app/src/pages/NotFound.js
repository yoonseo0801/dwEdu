import React from 'react';

const NotFound = () => {
  return <h1>404 - 페이지를 찾을 수 없습니다.</h1>;
};

export default NotFound;